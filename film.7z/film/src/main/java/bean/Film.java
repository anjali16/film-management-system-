package bean;

import java.util.Date;
import java.util.List;

import javax.persistence.*;
@Entity
public class Film {
	
	@Id  @GeneratedValue(strategy=GenerationType.AUTO) 
	private int id;
	String title;
	String description;
	int releaseYear;
	String language;
	byte rating;
	

	@OneToOne
	Album album;
	
	@ManyToMany(cascade = {CascadeType.ALL})
	List<Actor> actors;
	
	@ManyToMany(cascade = {CascadeType.ALL})
	List<Category> categorys;
	
	Date createDate;
	Date deleteDate;
	short length;
	
	
	public Film(){}
	public Film(int id, String title, String description, short releaseYear, String language, byte rating, Album album,
			List<Actor> actors, List<Category> categorys, Date createDate, Date deleteDate, short length) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.releaseYear = releaseYear;
		this.language = language;
		this.rating = rating;
		this.album = album;
		this.actors = actors;
		this.categorys = categorys;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
		this.length = length;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(int i) {
		this.releaseYear = i;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public Album getAlbum() {
		return album;
	}
	public void setAlbum(Album album) {
		this.album = album;
	}
	public List<Actor> getActor() {
		return actors;
	}
	public void setActor(List<Actor> actor) {
		this.actors = actor;
	}
	public List<Category> getCategory() {
		return categorys;
	}
	public void setCategory(List<Category> category) {
		this.categorys = category;
	}
	
	public short getLength() {
		return length;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setLength(short length) {
		this.length = length;
	}
	
	public void setCreateDate(Date createdate) {
		this.createDate = createdate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public byte getRating() {
		return rating;
	}
	public void setRating(byte rating) {
		this.rating = rating;
	}
/*	@Override
	public String toString() {
		return "Film [id=" + id + ", title=" + title + ", description=" + description + ", releaseYear=" + releaseYear
				+ ", language=" + language + ", album=" + album + ", actor=" + actors +"rating= "+rating+ ", category=" + categorys
				+ ", rating=" + ", createDate=" +createDate+  ", length=" + length + ", deletedate="+deleteDate
				+  "]";
	}*/
	
}
