package implclasses;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import bean.Actor;
import bean.Album;
import bean.Category;
import bean.Film;
import bean.Image;
import interfaces.ActorDAO;
import interfaces.ActorService;
import interfaces.FilmDAO;

public class ActorServiceImpl implements ActorService {

	private ActorDAOImpl actorDAO;
	private FilmDAOImpl filmDAO;
	protected EntityManager em;

	public ActorServiceImpl(ActorDAOImpl actorDAO) {
		this.actorDAO = actorDAO;
	}

	public ActorServiceImpl(EntityManager em) {
		filmDAO = new FilmDAOImpl(em);
		actorDAO = new ActorDAOImpl(em);
	}

	public Actor addActor(HashMap mapActor) {
		if (mapActor == null) {
			throw new NullPointerException();

		} else {

			try {
				
				Actor actor = new Actor();
				actor.setFirstName((String)mapActor.get("firstName"));
				actor.setLastName((String)mapActor.get("lastName"));
				actor.setGender((String)mapActor.get("gender"));
				HashMap img = (HashMap) mapActor.get("album");
				List<Image> imgList = new ArrayList<Image>();
				for(String imgage:(List<String>)img.get("imgList")){
					Image im = new Image();
					im.setUrl(imgage);
					im.setCreatedate((Date)mapActor.get("createDate"));
					imgList.add(im);
					im =actorDAO.addImage(im);
				}
				
				Album album = new Album();
				album.setName((String)mapActor.get("albumName"));
				album.setCreateDate((Date)mapActor.get("createDate"));
				album.setImage(imgList);
				actorDAO.addAlbum(album);
				actor.setAlbum(album);
				actor.setCreateDate((Date)mapActor.get("createDate"));
				actor = actorDAO.save(actor);
				return actor;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	}

	public Actor modifyActor( HashMap mapActor) {

		if (mapActor.equals(null)) {
			throw new NullPointerException();

		} else {
			try {
				int i=0;
					Actor a=null;
				  Actor savedActor=actorDAO.modifyActor(i,a); 
					return savedActor;
				

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public String deleteActor(String name) {
		if (name.equals(null)) {
			throw new NullPointerException();
		} else {
			try {
				if (actorDAO.deleteActor(name))
					return "deleted";
				return "input not present";
			} catch (Exception e) {
				return "error";
			}

		}
	}

	public List<Actor> searchByName(String firstName, String lastName) {
		List<Actor> l = null;
		if (firstName.equals(null) || lastName.equals(null))
			throw new NullPointerException();
		try {
			l = actorDAO.searchByName(firstName, lastName);
			if (!l.isEmpty()) {
				return l;
			}
		} catch (Exception e) {
		}

		{
			return null;
		}
	}

}
