package implclasses;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import bean.*;

public class UserInterface {

	protected static EntityManager em;

	public static void main(String ar[]) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();
		FilmServiceImpl filmService = new FilmServiceImpl(em);
		ActorServiceImpl actorService = new ActorServiceImpl(em);

		em.getTransaction().begin();

		// ---------------------------film
		// Details---------------------------------------------------//
/*
		List<String> imgList = new ArrayList<String>();
		imgList.add("url1");
		imgList.add("url2");
		imgList.add("url3");

		HashMap actor1 = new HashMap();
		actor1.put("firstName", "Emrran");
		actor1.put("lastName", "Hashmi");
		actor1.put("gender", "male");

		HashMap actor2 = new HashMap();
		actor2.put("firstName", "Nargis");
		actor2.put("lastName", "Fakhri");
		actor2.put("gender", "female");
		
		HashMap actor3 = new HashMap();
		actor3.put("firstName", "Prachi");
		actor3.put("lastName", "Desai");
		actor3.put("gender", "female");

		HashMap actor4 = new HashMap();
		actor4.put("firstName", "Lara");
		actor4.put("lastName", "Dutta");
		actor4.put("gender", "female");

		List<HashMap> actorList = new ArrayList<HashMap>();
		actorList.add(actor1);
		actorList.add(actor2);
		actorList.add(actor3);
		actorList.add(actor4);
		
		HashMap category1 = new HashMap();
		category1.put("name", "Biopic");
		
		HashMap category2 = new HashMap();
		category2.put("name", "Sports Drama Film");
		
		HashMap category3 = new HashMap();
		category3.put("name", "Romentic");
		
		List<HashMap> categoryList = new ArrayList<HashMap>();
		categoryList.add(category1);
		categoryList.add(category2);
		
		
		HashMap film = new HashMap();
		film.put("title", "Azhar");
		film.put("releaseYear", 2016);
		film.put("rating", 3);
		film.put("length", 120);
		film.put("language", "Hindi");
		film.put("imgList", imgList);
		film.put("albumName", "azhar album");
		film.put("actors", actorList);
		film.put("categorys", categoryList);
		film.put("description", "Biopic of Mohammad Azrudin");
		film.put("createDate", new Date());

		filmService.addFilm(film);

	
		
		System.out.println("- --------------2 Film Details --------------- ");
		List<String> filmImg1 = new ArrayList<String>();
		filmImg1.add("urldf");
		filmImg1.add("urlgsdhgh");
		filmImg1.add("url33eqow");

	
		HashMap actor11 = new HashMap();
		actor11.put("firstName", "Poppy");
		actor11.put("lastName", "Montgomery");
		actor11.put("gender", "female");

		HashMap actor22 = new HashMap();
		actor22.put("firstName", "Adam ");
		actor22.put("lastName", "Kaufman");
		actor22.put("gender", "male");

		List<HashMap> actorList1 = new ArrayList<HashMap>();
		actorList1.add(actor11);
		actorList1.add(actor22);

		HashMap category11 = new HashMap();
		category11.put("name", "Comedy");

		HashMap category22 = new HashMap();
		category22.put("name", "Romentic");

		List<HashMap> categoryList1 = new ArrayList<HashMap>();
		categoryList1.add(category11);
		categoryList1.add(category22);

		HashMap film1 = new HashMap();
		film1.put("title", "Lying to Be Perfect");
		film1.put("releaseYear", 2010);
		film1.put("rating", 5);
		film1.put("length", 120);
		film1.put("language", "English");

		film1.put("albumName", "Hollywood");
		film1.put("actors", actorList1);
		film1.put("categorys", categoryList1);
		film1.put("imgList", filmImg1);
		film1.put("description",
				"An overweight magazine editor (Poppy Montgomery) leads a double life as a sassy advice columnist at night. To keep her alter ego a secret, she agrees to lose weight with two of her friends and embarks on a life-changing journey.");
		film1.put("createDate", new Date());

		filmService.addFilm(film1);*/

/*		System.out.println("- --------------search by language--------------- ");
		List<Film> list = filmService.searchByLanguage("Hindi");
		for (Film f : list) {
			System.out.println(f.getTitle() + f.getReleaseYear() + f.getRating() + f.getDescription() + f.getLength());
			List<Category> c = f.getCategory();
			for (Category cat : c) {
				System.out.println("category : " + cat.getName());
			}
			List<Actor> a = f.getActor();
			for (Actor act : a) {
				System.out.println("Actor : " + act.getFirstName() + " " + act.getLastName());
			}
		}
		System.out.println("- --------------search by title--------------- ");
		List<Film> listt = filmService.searchByTitle("Azhar");
		for (Film f : list) {
			System.out.println(f.getTitle() + f.getReleaseYear() + f.getRating() + f.getDescription() + f.getLength());
			List<Category> c = f.getCategory();
			for (Category cat : c) {
				System.out.println("category : " + cat.getName());
			}
			List<Actor> a = f.getActor();
			for (Actor act : a) {
				System.out.println("Actor : " + act.getFirstName() + " " + act.getLastName());
			}
		}
		System.out.println("- --------------search by release year--------------- ");
		List<Film> list2 = filmService.searchByReleaseYear(2016);
		for (Film f : list) {
			System.out.println(f.getTitle() + f.getReleaseYear() + f.getRating() + f.getDescription() + f.getLength());
			List<Category> c = f.getCategory();
			for (Category cat : c) {
				System.out.println("category : " + cat.getName());
			}
			List<Actor> a = f.getActor();
			for (Actor act : a) {
				System.out.println("Actor : " + act.getFirstName() + " " + act.getLastName());
			}
		}

		System.out.println("- --------------search by rating--------------- ");
		List<Film> list3 = filmService.searchByRating((byte) 5);
		for (Film f : list) {
			System.out.println(f.getTitle() + f.getReleaseYear() + f.getRating() + f.getDescription() + f.getLength());
			List<Category> c = f.getCategory();
			for (Category cat : c) {
				System.out.println("category : " + cat.getName());
			}
			List<Actor> a = f.getActor();
			for (Actor act : a) {
				System.out.println("Actor : " + act.getFirstName() + " " + act.getLastName());
			}
		}
		
		List<Film> list1 = filmService.searchByCategory("Comedy");
		for (Film filmm : list1) {
			System.out.println("film titile search by category: " + filmm.getTitle());
			for (Actor a : filmm.getActor()) {
				System.out.println("actors : " + a.getFirstName() + " " + a.getLastName());
			}
		}

		List<Film> list22 = filmService.searchByActor("Prachi");
		for (Film filmn : list22) {
			System.out.println("film titile search by actor : " + filmn.getTitle());
		} 
		*/
	//	 System.out.println(filmService.deleteFilm("Azhar"));
		
		

		// -----------------------------------Modify
		// Film-------------------------------------------------------------//
		List<String> filmImg2 = new ArrayList<String>();
		filmImg2.add("urwl");
		filmImg2.add("urlll");
		filmImg2.add("urrt");

	
		HashMap actor111 = new HashMap();
		actor111.put("firstName", "Salman");
		actor111.put("lastName", "Khan");
		actor111.put("gender", "male");

		HashMap actor222 = new HashMap();
		actor222.put("firstName", "Nawazuddin");
		actor222.put("lastName", "Siddiqi");
		actor222.put("gender", "male");
		
		

	/*	HashMap actor333 = new HashMap();
		actor333.put("firstName", "Harshali");
		actor333.put("lastName", "Malhotran");
		actor333.put("gender", "female");

		
		HashMap actor222 = new HashMap();
		actor222.put("firstName", "Saif Ali");
		actor222.put("lastName", "Khan");
		actor222.put("gender", "male");
		
		

		HashMap actor333 = new HashMap();
		actor333.put("firstName", "Karishma");
		actor333.put("lastName", "Kapoor");
		actor333.put("gender", "female");
*/
	/*	HashMap actor444 = new HashMap();
		actor444.put("firstName", "Kareena");
		actor444.put("lastName", "Kapoor");
		actor444.put("gender", "female");
		*/
		List<HashMap> actorList2 = new ArrayList<HashMap>();
		actorList2.add(actor111);
		actorList2.add(actor222);
	//	actorList2.add(actor333);
	//	actorList2.add(actor444);
		
		HashMap category111 = new HashMap();
		category111.put("name", "Emotional");
		
		
		HashMap category222 = new HashMap();
		category222.put("name", "family Drama");
		List<HashMap> categoryList11 = new ArrayList<HashMap>();
		categoryList11.add(category111);
		categoryList11.add(category222);
		
		HashMap film2 = new HashMap();
		film2.put("title", "Bajrangi");
		film2.put("releaseYear",2017);
		film2.put("rating", 4);
		film2.put("length", 120);
		film2.put("language", "Hindi");
		film2.put("imgList", filmImg2);
		film2.put("albumName", "ggsd");
		film2.put("actors", actorList2);
		film2.put("categorys", categoryList11);
		film2.put("description",
				"Pavan, a devoted follower of Lord Hanuman, faces numerous challenges when he tries to reunite Munni with her family after she gets lost while travelling back home with her mother.");
		film2.put("createDate", new Date());

		System.out.println(filmService.addFilm(film2));
		
	 
		
		List<String> filmImg = new ArrayList<String>();
		filmImg.add("urwl");
		filmImg.add("urlll");
		filmImg.add("urrt");
	
		
		List<String> actorImg2 = new ArrayList<String>();
		actorImg2.add("676");
		actorImg2.add("6h");
		actorImg2.add("89h");
		
		HashMap category11 = new HashMap();
		category11.put("name", "Romentic");
		
		List<HashMap> categoryList = new ArrayList<HashMap>();
		categoryList.add(category11);
	
		
		HashMap film3 = new HashMap();
		film3.put("title", "Mujhse Dosti Karoge!");
		film3.put("releaseYear",2002);
		film3.put("rating", 4);
		film3.put("length", 120);
		film3.put("language", "Hindi");
		film3.put("imgList", filmImg2);
		film3.put("albumName", "ggsd");
		film3.put("categorys", categoryList11);
		film3.put("description",
				"Raj, Tina and Pooja are friends. However, when Raj migrates to London, he keeps in touch with Tina via email but when Tina gets occupied with other things, Pooja and Raj get closer to each other.");
		film3.put("createDate", new Date());

		List<HashMap> filmList = new ArrayList<HashMap>();
		filmList.add(film2);
	//	filmList.add(film3);
		
		HashMap actor444 = new HashMap();
		actor444.put("firstName", "Kareena");
		actor444.put("lastName", "Kapoor");
		actor444.put("gender", "female");
		actor444.put("actorImg", actorImg2);
		actor444.put("filmList", filmList);
		actor444.put("album","Kareena Album");
		actor444.put("createDate", new Date());
		System.out.println(actorService.modifyActor(actor444));
		
		em.getTransaction().commit();
		em.close();
		emf.close();
	}
}
