package implclasses;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import bean.Actor;
import bean.Album;
import bean.Category;
import bean.Film;
import bean.Image;
import interfaces.ActorDAO;

public class ActorDAOImpl implements ActorDAO {

	private EntityManager em;

	public ActorDAOImpl(EntityManager em) {
		this.em = em;
	}

	public Actor save(Actor actor) {
		try{
			TypedQuery<Actor> query = em.createQuery("Select a from Actor a where a.firstName like :nam", Actor.class);
			Actor ac = query.setParameter("nam", actor.getFirstName()).getSingleResult();
			
			if(ac==null){
				em.persist(actor);
				return actor;
			}
			else return actor;
			}
			catch(NoResultException e){
				em.persist(actor);
				return actor;
			}
	}

	public List<Actor> searchByName(String firstName, String lastName) {
		
		TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.firstName =:f AND a.lastName =:l", Actor.class);
		List<Actor> list = query.setParameter("f", firstName).setParameter("l", lastName).getResultList();
		return list;
		
	}

	public List<Actor> searchByAge(byte age) {

		return null;
	}

	public Actor modifyActor(int id,Actor actor) {

		Actor savedActor =em.find(Actor.class, id);
		savedActor.setAlbum(actor.getAlbum());
		savedActor.setFirstName(actor.getFirstName());
		savedActor.setLastName(actor.getLastName());
		savedActor.setGender(actor.getGender());
		savedActor.setCreateDate(actor.getCreateDate());
		
		em.persist(savedActor);
		return savedActor;
	}

	public Boolean deleteActor(String name) {

		return null;
	}
	
	public List<Actor> getActors(){
		
		try{
		TypedQuery<Actor> query = em.createQuery("Select a from Actor a", Actor.class);
		List<Actor> ac = query.getResultList();
		
		return ac;
		}catch(NoResultException e){
			return null;
		}
		
	}
	public Album addAlbum(Album album) {

		em.persist(album);
		System.out.println("album save");
		return album;
	}

	public Image addImage(Image img) {

		try {

			em.persist(img);
			return img;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

}
