package implclasses;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import bean.Actor;
import bean.Album;
import bean.Category;
import bean.Film;
import bean.Image;
import interfaces.FilmDAO;

public class FilmDAOImpl implements FilmDAO {

	private EntityManager em;

	public FilmDAOImpl(EntityManager em) {
		this.em = em;
	}

	public Film save(Film film) {
		try{
			TypedQuery<Film> query = em.createQuery("Select a from Film a where a.title like :nam", Film.class);
			Film fm = query.setParameter("nam", film.getTitle()).getSingleResult();
			
			if(fm==null){
				em.persist(film);
				return film;
			}
			else return fm;
			}
			catch(NoResultException e){
				em.persist(film);
				return film;
			}
	}

	public List<Film> searchByCategory(String name) {
		try {
			TypedQuery<Category> query = em.createQuery("SELECT c FROM Category c where c.name like :nam",
					Category.class);
			Category category = query.setParameter("nam", name).getSingleResult();
			List<Film> filmList = new ArrayList();
			for (Film film : category.getFilm()) {

				filmList.add(film);
			}

			return filmList;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public List<Film> searchByActor(String actor) {
		try {
			TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.firstName LIKE :nam", Actor.class);
			Actor ac = query.setParameter("nam", actor).getSingleResult();

			List<Film> filmList = new ArrayList();
			for (Film film : ac.getFilm()) {

				filmList.add(film);
			}

			return filmList;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public List<Film> searchByRating(byte rating) {
		try {
			TypedQuery<Film> query = em.createQuery("SELECT f FROM Film f WHERE f.rating =:r", Film.class);
			List<Film> list = query.setParameter("r", rating).getResultList();
			System.out.println(list);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public Boolean modifyFilm(int id,Film film) {

		try {
			Film f = em.find(Film.class,id);
			System.out.println(f);
			f.setDescription(film.getDescription());
			f.setRating(film.getRating());
			f.setReleaseYear(film.getReleaseYear());
			f.setLength(film.getLength());
			f.setCreateDate(film.getCreateDate());
			f.setAlbum(film.getAlbum());
			f.setTitle(film.getTitle());
			f.setLanguage(film.getLanguage());
			f.setActor(film.getActor());
			f.setCategory(film.getCategory());
			em.persist(f);
			return true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public Boolean deleteFilm(String title) {
		try {
			List<Film> f = searchByTitle(title);
			for (Film film : f) {

				film.setDeleteDate(new Date());
				em.persist(film);

				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public List<Film> searchByTitle(String title) {
		try {
			TypedQuery<Film> query = em.createQuery("SELECT f FROM Film f WHERE f.title =:t", Film.class);
			List<Film> list = query.setParameter("t", title).getResultList();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public List<Film> searchByLanguage(String language) {
		try {
			TypedQuery<Film> query = em.createQuery("SELECT f FROM Film f WHERE f.language =:lang", Film.class);
			List<Film> list = query.setParameter("lang", language).getResultList();
			System.out.println(list);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<Film> searchByReleaseYear(int year) {
		try {
			TypedQuery<Film> query = em.createQuery("SELECT f FROM Film f WHERE f.releaseYear =:y", Film.class);
			List<Film> list = query.setParameter("y", year).getResultList();
			System.out.println(list);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Album findAlbum(String string) {
		try {

			System.out.println("in find album");
			TypedQuery<Album> query = em.createQuery("SELECT a FROM Album a WHERE a.Name LIKE :nam", Album.class);
			Album album = (Album) query.setParameter("nam", string).getSingleResult();

			return album;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Category findCategory(String string) {
		try {

			TypedQuery<Category> query = em.createQuery("Select a from Category a where a.name like :nam",
					Category.class);
			Category c = query.setParameter("nam", string).getSingleResult();
			System.out.println(c);
			return c;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Album addAlbum(Album album) {

		em.persist(album);
		System.out.println("album save");
		return album;
	}

	public Image addImage(Image img) {

		try {

			em.persist(img);
			return img;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public Category addCategory(Category c) {
		
		try{
		TypedQuery<Category> query = em.createQuery("Select a from Category a where a.name like :nam",
				Category.class);
		Category c1 = query.setParameter("nam", c.getName()).getSingleResult();
		
		if(c1==null){
			em.persist(c);
			return c;
		}
		else return c1;
		}
		catch(NoResultException e){
			em.persist(c);
			return c;
		}
	}

	public Album setImageOnAlbum(String name, List<Image> images) {
		System.out.println("in set img" + name);
		Album album = findAlbum(name);
		album.setImage(images);
		em.persist(album);
		System.out.println("end set img");
		return album;
	}

	public Actor findActor(String string) {
		try {
			TypedQuery<Actor> query = em.createQuery("Select a from Actor a where a.firstName like :nam", Actor.class);
			Actor a = query.setParameter("nam", string).getSingleResult();
			System.out.println(a);
			return a;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public Album modifyAlbum(int j, Album album) {
		Album albumm =em.find(Album.class, j);
		albumm.setCreateDate(album.getCreateDate());
		albumm.setName(album.getName());
		em.persist(albumm);
		return albumm;
	}

		public List<Film> getFilms(){
		
		try{
		TypedQuery<Film> query = em.createQuery("Select f from Film f", Film.class);
		List<Film> film = query.getResultList();
		
		return film;
		}catch(NoResultException e){
			return null;
		}
		
	}

		public List<Category> getCategorys() {
			try{
			TypedQuery<Category> query=em.createQuery("select c from Category c",Category.class);
			List<Category> categorys=query.getResultList();
			return categorys;
			}catch(NoResultException e){
				return null;
				}
			}

		public void setActorOnFilm(int id, Actor actor) {
			Film film = em.find(Film.class, id);
			List<Actor> list = new ArrayList<Actor>();
			list.add(actor);
			film.setActor(list);
			em.persist(film);
			
		}

		
		
}
