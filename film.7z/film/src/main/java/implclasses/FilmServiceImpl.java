package implclasses;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.engine.transaction.jta.platform.internal.SynchronizationRegistryBasedSynchronizationStrategy;

import bean.Actor;
import bean.Album;
import bean.Category;
import bean.Film;
import bean.Image;
import interfaces.ActorDAO;
import interfaces.FilmDAO;
import interfaces.FilmService;

public class FilmServiceImpl implements FilmService {

	private FilmDAOImpl filmDAO;
	private ActorDAOImpl actorDAO;
	private Category category;
	private Actor actor;

	public FilmServiceImpl(FilmDAOImpl filmDAO) {
		this.filmDAO = filmDAO;
	}

	public FilmServiceImpl(EntityManager em) {
		filmDAO = new FilmDAOImpl(em);
		actorDAO = new ActorDAOImpl(em);
	}

	public FilmServiceImpl() {
	}

	public String addFilm(HashMap map) {
		if (map == null) {
			throw new NullPointerException();

		} else {

			try {
				String title = (String) map.get("title");
				Album album = new Album();
				album.setName((String) map.get("albumName"));
				album.setCreateDate((Date) map.get("createDate"));
				album = filmDAO.addAlbum(album);

				System.out.println("end album");
				List<String> urlList = (List<String>) map.get("imgList");
				List<Image> iList = new ArrayList<Image>();
				for (String url : urlList) {

					Image i = new Image();
					i.setUrl(url);
					i.setAlbum(album);
					i.setCreateDate((Date) map.get("createDate"));
					iList.add(i);
					filmDAO.addImage(i);

				}
				List<Category> categoryList = new ArrayList<Category>();
				List<HashMap> categoryMap = (List<HashMap>) map.get("categorys");
				
				
						for (HashMap m : categoryMap) {
				
							
								Category newCategory = new Category();
								newCategory.setName((String) m.get("name"));
								newCategory.setCreateDate((Date) map.get("createDate"));
								category = filmDAO.addCategory(newCategory);
								categoryList.add(category);
							
						}
				
				
				List<Actor> actorList =new ArrayList<Actor>();
				List<HashMap> actorMap = (List<HashMap>) map.get("actors");
				
				
				for (HashMap a : actorMap){
					
					
						Actor act = new Actor();
						act.setFirstName((String) a.get("firstName"));
						act.setLastName((String) a.get("lastName"));
						act.setGender((String) a.get("gender"));
						act.setAlbum(album);
						act.setCreateDate((Date) map.get("createDate"));
						actor=actorDAO.save(act);
						actorList.add(actor);
					
				}
				
				Film film = new Film();
				film.setTitle(title);
				film.setLanguage((String) map.get("language"));

				film.setDescription((String) map.get("description"));
				byte b = ((Integer) map.get("rating")).byteValue();
				film.setRating(b);
				film.setReleaseYear(((Integer) map.get("releaseYear")).intValue());
				film.setLength(((Integer) map.get("length")).shortValue());
				film.setCreateDate((Date) map.get("createDate"));
				film.setActor(actorList);
				film.setCategory(categoryList);
				film.setAlbum(album);

				film = filmDAO.save(film);

				List<Film> list = new ArrayList<Film>();
				list.add(film);

				return "success";

			} catch (Exception e) {
				e.printStackTrace();
				return "error";
			}
		}

	}

	public List searchByCategory(String name) {
		List<Film> l = null;
		if (name.equals(null)) {
			throw new NullPointerException();
		} else {
			try {
				l = filmDAO.searchByCategory(name);
			} catch (Exception e) {
			}

			if (!l.isEmpty())
				return l;
			else
				return null;

		}

	}

	public List<Film> searchByActor(String first) {
		List<Film> l = null;
		if (first.equals(null)) {
			throw new NullPointerException();
		} else {
			try {

				l = filmDAO.searchByActor(first);
			} catch (Exception e) {
			}
			if (!l.isEmpty())
				return l;
			return null;
		}
	}

	public List<Film> searchByRating(byte rating) {
		List<Film> l = null;
		if (rating == 0 || rating > 6) {
			throw new IllegalArgumentException();
		} else {
			try {
				l = filmDAO.searchByRating(rating);
			} catch (Exception e) {
			}
			if (!l.isEmpty())
				return l;
			return null;
		}
	}

	public String modifyFilm(HashMap map) {
		Boolean f = false;
		if (map == null) {
			throw new NullPointerException();

		} else {
			try {
				String title = (String) map.get("title");
				List<Film> filmList = filmDAO.searchByTitle(title);
				for (Film film : filmList) {

					Album album = film.getAlbum();
					int j = album.getId();
					album.setName((String) map.get("albumName"));
					album.setCreateDate((Date) map.get("createDate"));
					album = filmDAO.modifyAlbum(j, album);

					System.out.println("end album");
					List<String> urlList = (List<String>) map.get("imgList");

					List<Image> iList = new ArrayList<Image>();
					for (String url : urlList) {

						Image i = new Image();
						i.setUrl(url);
						i.setAlbum(album);
						i.setCreateDate((Date) map.get("createDate"));
						iList.add(i);
						filmDAO.addImage(i);

					}
					
					List<Category> categoryList = new ArrayList<Category>();
					List<HashMap> categoryMap = (List<HashMap>) map.get("categorys");
					System.out.println("size cat : " + categoryMap.size());
					for (HashMap m : categoryMap) {
						
							Category newCategory = new Category();
							newCategory.setName((String) m.get("name"));
							newCategory.setCreateDate((Date) map.get("createDate"));
							
							category = filmDAO.addCategory(newCategory);
							categoryList.add(category);
						}
					
					
			
					List<Actor> actorList =new ArrayList<Actor>();
					List<HashMap> actorMap = (List<HashMap>) map.get("actors");
					boolean flag=false;
					for (HashMap a : actorMap){
						
						
							Actor act = new Actor();
							act.setFirstName((String) a.get("firstName"));
							act.setLastName((String) a.get("lastName"));
							act.setGender((String) a.get("gender"));
							act.setAlbum(album);
							act.setCreateDate((Date) map.get("createDate"));
							
							actor =actorDAO.save(act);
							actorList.add(actor);
						}
					
					
					film.setDescription((String) map.get("description"));
					byte b = ((Integer) map.get("rating")).byteValue();
					film.setRating(b);
					film.setReleaseYear(((Integer) map.get("releaseYear")).intValue());
					film.setLength(((Integer) map.get("length")).shortValue());
					film.setCreateDate((Date) map.get("createDate"));
					film.setActor(actorList);
					film.setCategory(categoryList);
					film.setAlbum(album);
					film.setTitle(title);
					film.setLanguage((String) map.get("language"));
					int id = film.getId();
					f = filmDAO.modifyFilm(id, film);

					List<Film> list = new ArrayList<Film>();
					list.add(film);

				}

				if (f)
					return "success";
				else
					return "fail";

			} catch (Exception e) {
				e.printStackTrace();
				return "error";
			}
		}

	}

	public String deleteFilm(String title) {
		if (title.equals(null)) {
			throw new NullPointerException();
		} else {
			try {
				if (filmDAO.deleteFilm(title))
					return "deleted";
				return "not deleted";
			} catch (Exception e) {
				return "error";
			}

		}

	}

	public List<Film> searchByTitle(String title) {
		List<Film> l = null;
		if (title.equals(null)) {
			System.out.println("title :" + null);
			throw new NullPointerException();
		} else {
			try {
				l = filmDAO.searchByTitle(title);
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (!l.isEmpty())
				return l;
			else
				return null;
		}

	}

	public List<Film> searchByLanguage(String language) {
		List<Film> l = null;
		if (language.equals(null)) {
			throw new NullPointerException();
		} else {
			try {
				l = filmDAO.searchByLanguage(language);
			} catch (Exception e) {
			}
			if (!l.isEmpty())
				return l;
			return null;
		}
	}

	public List<Film> searchByReleaseYear(int year) {
		List<Film> l = null;
		if (year == 0) {
			throw new NullPointerException();
		} else {
			try {
				l = filmDAO.searchByReleaseYear(year);
			} catch (Exception e) {
			}
			if (!l.isEmpty())
				return l;
			return null;
		}
	}

	
	
	public Album createAlbum(String s) {
		Album album = new Album();
		album.setName(s);
		Album a = filmDAO.addAlbum(album);
		return a;
	}

	public Image createImage(String string, Album album1) {
		Image img = new Image();
		img.setUrl(string);
		img.setAlbum(album1);
		Image i = filmDAO.addImage(img);
		return i;
	}

}
