package interfaces;

import java.util.List;

import bean.Actor;
import bean.Category;
import bean.Film;

public interface ActorDAO {

	public Actor save(Actor actor);

	public List<Actor> searchByName(String firstName, String lastName);

	public List<Actor> searchByAge(byte age);

	public Actor modifyActor(int id, Actor actor);

	public Boolean deleteActor(String name);
}
