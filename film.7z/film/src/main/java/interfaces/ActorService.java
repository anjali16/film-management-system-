package interfaces;

import java.util.HashMap;
import java.util.List;

import bean.Actor;
import bean.Category;
import bean.Film;

public interface ActorService {

	public Actor addActor(HashMap mapActor);

	public List<Actor> searchByName(String firstName, String lastName);

	public String modifyActor(HashMap actor);

	public String deleteActor(String firstName, String lastName);

}
